<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Payment.php';
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../models/AirlineUser.php';
require_once __DIR__ . '/../models/Loyalty.php';
require_once __DIR__ . '/../utils/Response.php';

class PaymentController {
    private $paymentModel;
    private $bookingModel;
    private $userModel;

    public function __construct() {
        $db = db();
        $this->paymentModel = new Payment($db);
        $this->bookingModel = new Booking($db);
        $this->userModel = new AirlineUser($db);
    }

    private function authenticate() {
        $headers = apache_request_headers();
        $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';
        $user_id = $this->userModel->validateToken($token);

        if (!$user_id) {
            Response::json(['status' => false, 'message' => 'Unauthorized'], 401);
            exit();
        }
        return $user_id;
    }

    /**
     * Idempotent helper to finalize a successful payment:
     * - Marks booking as paid (if not already)
     * - Optionally stores a receipt/transaction reference
     * - Sends ticket
     * - Awards loyalty points
     */
    private function finalizeSuccessfulPayment(array $booking, string $method, ?string $receipt = null): void
    {
        if (empty($booking['id'])) {
            return;
        }

        // If already marked as paid, do nothing (idempotent behavior)
        if (($booking['payment_status'] ?? null) === 'paid') {
            return;
        }

        $this->bookingModel->updatePaymentStatus(
            $booking['id'],
            'paid',
            $method
        );

        // Optionally persist a transaction / receipt reference if supported
        if ($receipt && method_exists($this->bookingModel, 'updateTransactionReference')) {
            $this->bookingModel->updateTransactionReference($booking['id'], $receipt);
        }

        // Send combined e-ticket & receipt
        $this->sendTicket($booking['id']);

        // Award Loyalty Points if user is logged in
        if (!empty($booking['user_id'])) {
            $loyalty = new Loyalty(db());
            $loyalty->awardPoints($booking['user_id'], $booking['id'], $booking['total_amount']);
        }
    }

    public function updatePayment() {
        $data = request_json();
        
        if (empty($data['booking_id']) || empty($data['status'])) {
            Response::json(['status' => false, 'message' => 'Missing payment details'], 400);
            return;
        }

        $success = $this->bookingModel->updatePaymentStatus(
            $data['booking_id'],
            $data['status'],
            $data['payment_method'] ?? null
        );

        if ($success) {
            Response::json(['status' => true, 'message' => 'Payment status updated']);
        } else {
            Response::json(['status' => false, 'message' => 'Failed to update payment status'], 500);
        }
    }

    public function initializePaystack() {
        $data = request_json();

        // Validate required fields
        if (empty($data['email']) || empty($data['amount']) || empty($data['booking_reference'])) {
            Response::json(['status' => false, 'message' => 'Missing required payment details'], 400);
            return;
        }

        require_once __DIR__ . '/../services/PaystackService.php';
        $paystack = new PaystackService();

        // Convert amount to kobo (Paystack uses smallest currency unit)
        // For KES: 1 KES = 100 cents
        $amountInKobo = (int)($data['amount'] * 100);

        $metadata = [
            'booking_reference' => $data['booking_reference'],
            'custom_fields' => [
                [
                    'display_name' => 'Booking Reference',
                    'variable_name' => 'booking_reference',
                    'value' => $data['booking_reference']
                ]
            ]
        ];

        $response = $paystack->initializeTransaction(
            $data['email'],
            $amountInKobo,
            $data['booking_reference'],
            $metadata,
            $data['currency'] ?? 'KES'
        );

        if ($response['status']) {
            Response::json([
                'status' => true,
                'data' => $response['data'],
                'message' => 'Payment initialized successfully'
            ]);
        } else {
            Response::json([
                'status' => false,
                'message' => $response['message'] ?? 'Failed to initialize payment'
            ], 500);
        }
    }

    public function verifyPaystack() {
        $reference = $_GET['reference'] ?? '';

        if (empty($reference)) {
            Response::json(['status' => false, 'message' => 'Payment reference is required'], 400);
            return;
        }

        require_once __DIR__ . '/../services/PaystackService.php';
        $paystack = new PaystackService();

        $response = $paystack->verifyTransaction($reference);

        if ($response['status'] && isset($response['data'])) {
            $transactionData = $response['data'];

            // Update booking payment status
            if ($transactionData['status'] === 'success') {
                $bookingReference = $transactionData['metadata']['booking_reference'] ?? $reference;
                
                // Get booking by reference and finalize if found
                $booking = $this->bookingModel->getByReference($bookingReference);
                
                if ($booking) {
                    $this->finalizeSuccessfulPayment($booking, 'paystack');

                    Response::json([
                        'status' => true,
                        'message' => 'Payment verified successfully',
                        'data' => $transactionData
                    ]);
                } else {
                    Response::json([
                        'status' => false,
                        'message' => 'Booking not found'
                    ], 404);
                }
            } else {
                Response::json([
                    'status' => false,
                    'message' => 'Payment not successful',
                    'data' => $transactionData
                ]);
            }
        } else {
            Response::json([
                'status' => false,
                'message' => $response['message'] ?? 'Failed to verify payment'
            ], 500);
        }
    }

    public function paystackWebhook() {
        // Verify webhook signature
        $input = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';

        if (!$signature) {
            http_response_code(400);
            exit();
        }

        $webhookSecret = env('PAYSTACK_SECRET_KEY'); // Use secret key for signature verification
        if ($signature !== hash_hmac('sha512', $input, $webhookSecret)) {
             http_response_code(401);
             exit();
        }

        $event = json_decode($input, true);

        if ($event['event'] === 'charge.success') {
            $data = $event['data'];
            $reference = $data['reference'];
            $bookingReference = $data['metadata']['booking_reference'] ?? $reference;

            // Update booking status
            $booking = $this->bookingModel->getByReference($bookingReference);
            if ($booking) {
                $this->finalizeSuccessfulPayment($booking, 'paystack');
            }
        }

        http_response_code(200);
        echo json_encode(['status' => 'success']);
    }

    public function initializeMpesa() {
        $data = request_json();
        
        // Validate required fields
        if (empty($data['phone_number'])) {
            Response::json(['status' => false, 'message' => 'Phone number is required'], 400);
            return;
        }
        if (empty($data['amount']) || $data['amount'] <= 0) {
            Response::json(['status' => false, 'message' => 'Valid amount is required'], 400);
            return;
        }
        if (empty($data['booking_reference'])) {
            Response::json(['status' => false, 'message' => 'Booking reference is required'], 400);
            return;
        }
        
        require_once __DIR__ . '/../services/MpesaService.php';
        $mpesa = new MpesaService(db());
        
        $response = $mpesa->initiateStkPush(
            $data['phone_number'],
            $data['amount'],
            $data['booking_reference'],
            $data['description'] ?? 'Flight Booking Payment'
        );
        
        if ($response['status']) {
            // Update booking to indicate payment is pending
            $booking = $this->bookingModel->getByReference($data['booking_reference']);
            if ($booking) {
                $this->bookingModel->updatePaymentStatus(
                    $booking['id'],
                    'pending',
                    'mpesa'
                );
            }
            
            Response::json([
                'status' => true,
                'message' => $response['message'],
                'data' => $response['data']
            ]);
        } else {
            Response::json([
                'status' => false, 
                'message' => $response['message'],
                'error_code' => $response['error_code'] ?? 'MPESA_ERROR'
            ], 500);
        }
    }

    public function mpesaCallback() {
        // Get raw POST data
        $rawInput = file_get_contents('php://input');
        $data = json_decode($rawInput, true);
        
        // Log raw callback for debugging
        $logDir = __DIR__ . '/../logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        file_put_contents(
            $logDir . '/mpesa_callbacks_' . date('Y-m-d') . '.log',
            date('Y-m-d H:i:s') . " CALLBACK: " . $rawInput . PHP_EOL,
            FILE_APPEND
        );
        
        if (!$data || !isset($data['Body']['stkCallback'])) {
            http_response_code(400);
            echo json_encode(['ResultCode' => 1, 'ResultDesc' => 'Invalid callback data']);
            exit();
        }
        
        require_once __DIR__ . '/../services/MpesaService.php';
        $mpesa = new MpesaService(db());
        
        $result = $mpesa->processCallback($data);
        
        if ($result['status'] && $result['payment_status'] === 'success') {
            // Payment successful - update booking
            $paymentData = $result['data'];
            $bookingReference = $paymentData['booking_reference'];
            
            if ($bookingReference) {
                $booking = $this->bookingModel->getByReference($bookingReference);
                
                if ($booking) {
                    $receipt = $paymentData['mpesa_receipt'] ?? null;
                    $this->finalizeSuccessfulPayment($booking, 'mpesa', $receipt);
                }
            }
            
            // Respond to Safaricom
            http_response_code(200);
            echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Callback processed successfully']);
        } else {
            // Payment failed or cancelled
            $paymentData = $result['data'] ?? [];
            $bookingReference = $paymentData['booking_reference'] ?? null;
            
            if ($bookingReference) {
                $booking = $this->bookingModel->getByReference($bookingReference);
                if ($booking) {
                    $this->bookingModel->updatePaymentStatus(
                        $booking['id'],
                        'failed',
                        'mpesa'
                    );
                }
            }
            
            http_response_code(200);
            echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Callback received']);
        }
        exit();
    }

    public function queryMpesaStatus() {
        $checkoutRequestId = $_GET['checkout_request_id'] ?? '';
        
        if (empty($checkoutRequestId)) {
            Response::json(['status' => false, 'message' => 'checkout_request_id is required'], 400);
            return;
        }
        
        require_once __DIR__ . '/../services/MpesaService.php';
        $mpesa = new MpesaService(db());
        
        $response = $mpesa->queryStkStatus($checkoutRequestId);
        
        Response::json($response);
    }

    public function initiate() {
        $user_id = $this->authenticate();
        $data = request_json();

        if (empty($data['booking_id']) || empty($data['amount']) || empty($data['payment_method'])) {
            Response::json(['status' => false, 'message' => 'Missing payment details: booking_id, amount, payment_method required'], 400);
            return;
        }

        // Verify booking exists and belongs to user
        $booking = $this->bookingModel->getById($data['booking_id']);
        
        if (!$booking) {
            Response::json(['status' => false, 'message' => 'Booking not found'], 404);
            return;
        }
        
        if ($booking['user_id'] != $user_id) {
            Response::json(['status' => false, 'message' => 'Unauthorized: Booking does not belong to you'], 403);
            return;
        }

        // Server-side integrity checks: ensure amount and status are valid before
        // handing off to any payment gateway.
        $requestedAmount = (float)$data['amount'];
        $expectedAmount = isset($booking['total_amount']) ? (float)$booking['total_amount'] : 0.0;
        $paymentStatus = $booking['payment_status'] ?? null;

        // Prevent re-payment of already paid bookings
        if ($paymentStatus === 'paid') {
            Response::conflict('Booking is already marked as paid');
        }

        if ($expectedAmount <= 0) {
            error_log('Booking ' . $booking['id'] . ' has non-positive total_amount; blocking payment initiate');
            Response::json(['status' => false, 'message' => 'Booking has invalid total amount'], 400);
        }

        // Allow for minor rounding differences, but block obvious tampering.
        $delta = abs($requestedAmount - $expectedAmount);
        if ($delta > 0.01) {
            Response::json([
                'status' => false,
                'message' => 'Amount does not match booking total',
            ], 400);
        }

        $paymentMethod = strtolower($data['payment_method']);
        
        // Route to appropriate payment gateway
        if ($paymentMethod === 'mpesa' || $paymentMethod === 'm-pesa') {
            // M-Pesa STK Push
            if (empty($data['phone_number'])) {
                Response::json(['status' => false, 'message' => 'Phone number required for M-Pesa'], 400);
                return;
            }
            
            require_once __DIR__ . '/../services/MpesaService.php';
            $mpesa = new MpesaService(db());
            
            $response = $mpesa->initiateStkPush(
                $data['phone_number'],
                $data['amount'],
                $booking['reference'],
                'Flight Booking - ' . $booking['reference']
            );
            
            if ($response['status']) {
                Response::json([
                    'status' => true,
                    'message' => $response['message'],
                    'payment_method' => 'mpesa',
                    'data' => $response['data']
                ]);
            } else {
                Response::json([
                    'status' => false,
                    'message' => $response['message'],
                    'error_code' => $response['error_code'] ?? 'MPESA_ERROR'
                ], 500);
            }
            
        } elseif ($paymentMethod === 'card' || $paymentMethod === 'paystack') {
            // Paystack Card Payment
            if (empty($data['email'])) {
                Response::json(['status' => false, 'message' => 'Email required for card payment'], 400);
                return;
            }
            
            require_once __DIR__ . '/../services/PaystackService.php';
            $paystack = new PaystackService();
            
            $amountInKobo = (int)($data['amount'] * 100);
            
            $metadata = [
                'booking_reference' => $booking['reference'],
                'booking_id' => $booking['id'],
                'custom_fields' => [
                    ['display_name' => 'Booking Reference', 'variable_name' => 'booking_reference', 'value' => $booking['reference']]
                ]
            ];
            
            $response = $paystack->initializeTransaction(
                $data['email'],
                $amountInKobo,
                $booking['reference'],
                $metadata
            );
            
            if ($response['status']) {
                Response::json([
                    'status' => true,
                    'message' => 'Payment initialized',
                    'payment_method' => 'paystack',
                    'data' => $response['data']
                ]);
            } else {
                Response::json([
                    'status' => false,
                    'message' => $response['message'] ?? 'Failed to initialize payment'
                ], 500);
            }
            
        } else {
            Response::json(['status' => false, 'message' => 'Unsupported payment method: ' . $paymentMethod], 400);
        }
    }

    // Generic callback for payment confirmation (legacy support)
    public function callback() {
        $data = request_json();
        
        if (empty($data['transaction_id']) || empty($data['status'])) {
            Response::json(['status' => false, 'message' => 'Missing transaction_id or status'], 400);
            return;
        }
        
        $db = db();
        
        // Get the transaction from payment_transactions
        $stmt = $db->prepare("
            SELECT pt.*, b.reference as booking_reference 
            FROM payment_transactions pt
            LEFT JOIN bookings b ON pt.booking_id = b.id
            WHERE pt.transaction_id = ? OR pt.payment_reference = ?
        ");
        $stmt->execute([$data['transaction_id'], $data['transaction_id']]);
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$transaction) {
            Response::json(['status' => false, 'message' => 'Transaction not found'], 404);
            return;
        }
        
        // Update payment transaction status
        $newStatus = ($data['status'] === 'completed' || $data['status'] === 'success') ? 'completed' : 'failed';
        
        $updateStmt = $db->prepare("
            UPDATE payment_transactions 
            SET status = ?, payment_date = NOW(), metadata = ?
            WHERE id = ?
        ");
        $updateStmt->execute([$newStatus, json_encode($data), $transaction['id']]);
        
        // Update booking status
        if ($newStatus === 'completed') {
            $this->bookingModel->updatePaymentStatus(
                $transaction['booking_id'],
                'paid',
                $transaction['payment_method']
            );
        } else {
            $this->bookingModel->updatePaymentStatus(
                $transaction['booking_id'],
                'failed',
                $transaction['payment_method']
            );
        }
        
        Response::json([
            'status' => true, 
            'message' => 'Payment status updated',
            'payment_status' => $newStatus
        ]);
    }
    private function sendTicket($bookingId) {
        require_once __DIR__ . '/../services/TicketService.php';
        require_once __DIR__ . '/../models/BookingPassenger.php';
        
        $passengerModel = new BookingPassenger(db()); // Instantiate ad-hoc or add to constructor
        
        $booking = $this->bookingModel->getById($bookingId);
        $passengers = $passengerModel->getByBookingId($bookingId);
        
        TicketService::getInstance()->sendTicket($booking, $passengers);
    }

    // ==================== ONAFRIQ (Mobile Money) ====================

    public function initializeOnafriq() {
        $data = request_json();

        if (empty($data['phone_number']) || empty($data['amount']) || empty($data['booking_reference'])) {
            Response::json(['status' => false, 'message' => 'Missing required payment details'], 400);
            return;
        }

        require_once __DIR__ . '/../services/OnafriqService.php';
        $db = db();
        $onafriq = new OnafriqService($db);

        $response = $onafriq->initiateMobileMoneyPayment(
            $data['phone_number'],
            $data['amount'],
            $data['currency'] ?? 'XAF',
            $data['booking_reference'],
            $data['provider'] ?? 'orange',
            $data['country_code'] ?? '243'
        );

        if ($response['status']) {
            Response::json([
                'status' => true,
                'data' => $response['data'],
                'message' => $response['message']
            ]);
        } else {
            Response::json([
                'status' => false,
                'message' => $response['message'] ?? 'Failed to initialize payment'
            ], 500);
        }
    }

    public function onafriqCallback() {
        $callbackData = request_json();

        // Optional: Verify signature if Onafriq provides X-Signature header
        // $signature = $_SERVER['HTTP_X_ONAFRIQ_SIGNATURE'] ?? '';
        // verifySignature($callbackData, $signature);

        require_once __DIR__ . '/../services/OnafriqService.php';
        $db = db();
        $onafriq = new OnafriqService($db);

        $result = $onafriq->processCallback($callbackData);

        if ($result['status'] && $result['payment_status'] === 'success') {
            $bookingReference = $result['data']['booking_reference'];
            $booking = $this->bookingModel->getByReference($bookingReference);

            if ($booking) {
                $this->finalizeSuccessfulPayment($booking, 'onafriq');
            }
        }
        
        // Respond to Onafriq to acknowledge receipt
        Response::json($result);
    }

    public function onafriqStatus() {
        $transactionId = $_GET['transaction_id'] ?? '';

        if (empty($transactionId)) {
            Response::json(['status' => false, 'message' => 'Transaction ID is required'], 400);
            return;
        }

        require_once __DIR__ . '/../services/OnafriqService.php';
        $db = db();
        $onafriq = new OnafriqService($db);

        $response = $onafriq->queryTransactionStatus($transactionId);
        Response::json($response);
    }

    // ==================== DPO PAY (Cards) ====================

    public function initializeDPO() {
        $data = request_json();

        if (empty($data['amount']) || empty($data['booking_reference']) || empty($data['email'])) {
            Response::json(['status' => false, 'message' => 'Missing required payment details'], 400);
            return;
        }

        require_once __DIR__ . '/../services/DPOService.php';
        $db = db();
        $dpo = new DPOService($db);

        $response = $dpo->createToken(
            $data['amount'],
            $data['currency'] ?? 'USD',
            $data['booking_reference'],
            $data['email'],
            $data['customer_name'] ?? '',
            $data['phone_number'] ?? ''
        );

        if ($response['status']) {
            Response::json([
                'status' => true,
                'data' => $response['data'],
                'message' => $response['message']
            ]);
        } else {
            Response::json([
                'status' => false,
                'message' => $response['message'] ?? 'Failed to initialize payment'
            ], 500);
        }
    }

    public function dpoCallback() {
        // DPO sends data via GET parameters (TransToken, CompanyRef, etc.) or POST XML depending on config
        // Assuming GET redirection for browser return, and POST for server-to-server (if configured)
        
        $callbackData = $_GET; 
        
        // If empty GET, check input stream for XML (server-to-server notification)
        if (empty($callbackData)) {
            $input = file_get_contents('php://input');
            if (!empty($input)) {
                // Parse XML notification
                try {
                     $xml = simplexml_load_string($input);
                     $callbackData = json_decode(json_encode($xml), true);
                } catch (Exception $e) {
                    // Log error
                }
            }
        }

        require_once __DIR__ . '/../services/DPOService.php';
        $db = db();
        $dpo = new DPOService($db);

        $result = $dpo->processCallback($callbackData);

        if ($result['status'] && $result['payment_status'] === 'success') {
            $bookingReference = $result['data']['booking_reference'];
            $booking = $this->bookingModel->getByReference($bookingReference);

            if ($booking) {
                $this->finalizeSuccessfulPayment($booking, 'dpo');
            }
        }

        // If it's a browser redirect (has TransToken in GET), redirect users
        if (isset($_GET['TransToken']) || isset($_GET['trans_token'])) {
             $status = $result['payment_status'] === 'success' ? 'success' : 'failed';
             $ref = $result['data']['booking_reference'] ?? '';
             header("Location: " . env('APP_URL') . "/payment/result?status=$status&reference=$ref");
             exit();
        }
        
        // Otherwise acknowledge receipt (for server-to-server)
        echo "OK"; 
        exit();
    }

    public function verifyDPO() {
        $transToken = $_GET['trans_token'] ?? '';

        if (empty($transToken)) {
            Response::json(['status' => false, 'message' => 'Transaction token is required'], 400);
            return;
        }

        require_once __DIR__ . '/../services/DPOService.php';
        $db = db();
        $dpo = new DPOService($db);

        $response = $dpo->verifyTransaction($transToken);

        if ($response['status']) {
            Response::json([
                'status' => true,
                'data' => $response['data'],
                'transaction_status' => $response['transaction_status']
            ]);
        } else {
            Response::json([
                'status' => false,
                'message' => $response['message'] ?? 'Failed to verify payment'
            ], 500);
        }
    }
}
?>
