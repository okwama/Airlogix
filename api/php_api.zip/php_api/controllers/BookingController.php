<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../models/Passenger.php';
require_once __DIR__ . '/../models/BookingPassenger.php';
require_once __DIR__ . '/../models/AirlineUser.php'; // For token validation
require_once __DIR__ . '/../models/Loyalty.php';
require_once __DIR__ . '/../utils/Response.php';

class BookingController {
    private $bookingModel;
    private $passengerModel;
    private $bookingPassengerModel;
    private $userModel;

    public function __construct() {
        $db = db();
        $this->bookingModel = new Booking($db);
        $this->passengerModel = new Passenger($db);
        $this->bookingPassengerModel = new BookingPassenger($db);
        $this->userModel = new AirlineUser($db);
    }

    private function authenticate() {
        $headers = apache_request_headers();
        $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';
        $user_id = $this->userModel->validateToken($token);

        if (!$user_id) {
            Response::json(['status' => false, 'message' => 'Unauthorized'], 401);
            exit();
        }
        return $user_id;
    }


    public function create() {
        // Authentication optional for bookings (guests can book)
        // $user_id = $this->authenticate();
        $data = request_json();

        // Support both old single-passenger and new multi-passenger formats
        $passengers = [];
        
        if (isset($data['passengers']) && is_array($data['passengers'])) {
            // New format: array of passengers
            $passengers = $data['passengers'];
        } else if (isset($data['passenger_name'])) {
            // Old format: single passenger fields (backward compatibility)
            $passengers = [[
                'name' => $data['passenger_name'],
                'email' => $data['passenger_email'] ?? null,
                'contact' => $data['passenger_phone'] ?? null,
                'passenger_type' => $data['passenger_type'] ?? 'adult',
                'nationality' => $data['nationality'] ?? null,
                'identification' => $data['identification'] ?? null,
                'age' => $data['age'] ?? null,
                'title' => $data['title'] ?? null
            ]];
        }

        // Validate required fields
        if (empty($data['flight_series_id']) || empty($passengers) || empty($data['total_amount'])) {
            Response::json(['status' => false, 'message' => 'Missing required booking details'], 400);
            return;
        }

        // Basic server-side fare integrity: ensure that the total amount is
        // consistent with the per-passenger fare and number of passengers.
        $numPassengers = count($passengers);
        $clientTotal = (float)$data['total_amount'];

        if ($numPassengers <= 0 || $clientTotal <= 0) {
            Response::json(['status' => false, 'message' => 'Invalid passenger count or total amount'], 400);
            return;
        }

        // If client provided a per-passenger fare, use it; otherwise derive it.
        $farePerPassenger = isset($data['fare_per_passenger'])
            ? (float)$data['fare_per_passenger']
            : ($clientTotal / $numPassengers);

        if ($farePerPassenger <= 0) {
            Response::json(['status' => false, 'message' => 'Invalid fare per passenger'], 400);
            return;
        }

        $expectedTotal = round($farePerPassenger * $numPassengers, 2);
        $delta = abs($expectedTotal - $clientTotal);

        // Allow a tiny rounding difference but block obvious tampering.
        if ($delta > 0.01) {
            Response::json([
                'status' => false,
                'message' => 'Total amount does not match fare per passenger and passenger count',
            ], 400);
            return;
        }

        // Start transaction
        $db = db();
        $db->beginTransaction();

        try {
            // Securely set user_id if token is present
            $headers = apache_request_headers();
            $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';
            $authUserId = $this->userModel->validateToken($token);
            $userId = $authUserId ?: ($data['user_id'] ?? null);

            $primaryPassenger = $passengers[0];
            $bookingData = [
                'flight_series_id' => $data['flight_series_id'],
                'cabin_class_id' => $data['cabin_class_id'] ?? 1, // Defaulting to Economy if not provided
                'passenger_name' => $primaryPassenger['name'],
                'passenger_email' => $primaryPassenger['email'] ?? null,
                'passenger_phone' => $primaryPassenger['contact'] ?? null,
                'passenger_type' => $primaryPassenger['passenger_type'] ?? 'adult',
                'number_of_passengers' => $numPassengers,
                'fare_per_passenger' => $farePerPassenger,
                // Persist the server-computed canonical total, not arbitrary client value
                'total_amount' => $expectedTotal,
                'payment_method' => $data['payment_method'] ?? 'pending',
                'notes' => $data['notes'] ?? null,
                'user_id' => $userId
            ];

            $bookingResponse = $this->bookingModel->create($bookingData);
            
            if (!$bookingResponse['status']) {
                throw new Exception($bookingResponse['message'] ?? 'Failed to create booking');
            }

            $bookingId = $bookingResponse['booking_id'];
            $bookingReference = $bookingResponse['reference'];

            // Create passengers and link to booking
            $createdPassengers = [];
            foreach ($passengers as $passengerData) {
                // Create passenger record
                $passenger = $this->passengerModel->create([
                    'name' => $passengerData['name'],
                    'email' => $passengerData['email'] ?? null,
                    'contact' => $passengerData['contact'] ?? null,
                    'nationality' => $passengerData['nationality'] ?? null,
                    'identification' => $passengerData['identification'] ?? null,
                    'age' => $passengerData['age'] ?? null,
                    'title' => $passengerData['title'] ?? null
                ]);

                if (!$passenger) {
                    throw new Exception('Failed to create passenger');
                }

                // Link passenger to booking
                $fareAmount = $passengerData['fare_amount'] ?? $bookingData['fare_per_passenger'];
                $passengerType = $passengerData['passenger_type'] ?? 'adult';
                
                $linkCreated = $this->bookingPassengerModel->create(
                    $bookingId,
                    $passenger['id'],
                    $passengerType,
                    $fareAmount
                );

                if (!$linkCreated) {
                    throw new Exception('Failed to link passenger to booking');
                }

                $createdPassengers[] = [
                    'passenger_id' => $passenger['id'],
                    'pnr' => $passenger['pnr'],
                    'name' => $passenger['name'],
                    'email' => $passenger['email'],
                    'passenger_type' => $passengerType,
                    'fare_amount' => $fareAmount
                ];
            }

            // Commit transaction
            $db->commit();

            // Return success response with all passenger details
            Response::json([
                'status' => true,
                'message' => 'Booking created successfully',
                'booking_id' => $bookingId,
                'reference' => $bookingReference,
                'data' => array_merge($bookingResponse['data'], [
                    'passengers' => $createdPassengers
                ])
            ]);

        } catch (Exception $e) {
            // Rollback transaction on error
            $db->rollBack();
            error_log("Booking creation error: " . $e->getMessage());
            Response::json([
                'status' => false,
                'message' => 'Failed to create booking: ' . $e->getMessage()
            ], 500);
        }
    }

    public function listByPassenger($passenger_id) {
        // Optional: Add authentication check
        $bookings = $this->bookingModel->getByPassenger($passenger_id);
        Response::json(['status' => true, 'data' => $bookings]);
    }

    public function listAll() {
        // Admin only - should add admin check
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        
        $bookings = $this->bookingModel->getAll($limit, $offset);
        Response::json([
            'status' => true, 
            'data' => $bookings,
            'count' => count($bookings)
        ]);
    }


    public function get($reference) {
        $booking = $this->bookingModel->getByReference($reference);
        
        if ($booking) {
            // Get passengers for this booking
            $passengers = $this->bookingPassengerModel->getByBookingId($booking['id']);
            $booking['passengers'] = $passengers;
            
            Response::json(['status' => true, 'data' => $booking]);
        } else {
            Response::json(['status' => false, 'message' => 'Booking not found'], 404);
        }
    }
    
    public function listByUser() {
        // Securely get user_id from auth token
        $userId = $this->authenticate();
        
        $bookings = $this->bookingModel->getByUserId($userId);
        
        // Add passengers to each booking
        foreach ($bookings as &$booking) {
            $passengers = $this->bookingPassengerModel->getByBookingId($booking['id']);
            $booking['passengers'] = $passengers;
        }
        
        Response::json([
            'status' => true,
            'data' => $bookings,
            'count' => count($bookings)
        ]);
    }

    public function updatePayment() {
        $data = request_json();
        
        if (empty($data['booking_id']) || empty($data['status'])) {
            Response::json(['status' => false, 'message' => 'Missing payment details'], 400);
            return;
        }

        $success = $this->bookingModel->updatePaymentStatus(
            $data['booking_id'],
            $data['status'],
            $data['payment_method'] ?? null
        );

        if ($success) {
            // Trigger Ticket Email if status is PAID
            if ($data['status'] === 'paid') {
                require_once __DIR__ . '/../services/TicketService.php';
                $booking = $this->bookingModel->getById($data['booking_id']);
                
                if ($booking) {
                    // Fetch passengers for the ticket
                    $passengers = $this->bookingPassengerModel->getByBookingId($data['booking_id']);
                    
                    // Sending combined e-ticket & receipt
                    $sent = TicketService::getInstance()->sendTicket($booking, $passengers);
                    if (!$sent) {
                        error_log("Payment marked as PAID but document delivery failed for Ref: " . $booking['booking_reference']);
                    }
                    
                    // Award Loyalty Points if user is logged in
                    if (!empty($booking['user_id'])) {
                        require_once __DIR__ . '/LoyaltyController.php'; // Ensure loyalty model/logic is accessible
                        $loyalty = new Loyalty(db());
                        $loyalty->awardPoints($booking['user_id'], $booking['id'], $booking['total_amount']);
                    }
                } else {
                    error_log("Severe: Payment marked as PAID for non-existent booking ID: " . $data['booking_id']);
                }
            }
            
            Response::json(['status' => true, 'message' => 'Payment status updated']);
        } else {
            error_log("Failed to update payment status for booking ID: " . ($data['booking_id'] ?? 'unknown'));
            Response::json(['status' => false, 'message' => 'Failed to update payment status'], 500);
        }
    }

    /**
     * ARCHITECTURAL GUARDRAILS (IATA DISTRIBUTION STANDARDS)
     * 
     * The following notes specify where critical GDS/Airline distribution logic
     * should reside in a production multi-channel environment:
     * 
     * 1. FARE REVALIDATION:
     *    Must occur immediately before payment capture. If the GDS quote 
     *    expires or shifts, the transaction must be aborted to prevent ADMs.
     * 
     * 2. PNR LIFECYCLE (TTL):
     *    A background worker/daemon must monitor 'pending' bookings. If not 
     *    ticketed within the Time-To-Limit (TTL) provided by the GDS, the 
     *    inventory must be released (Status: XX) to avoid "Inventory Spoilage" fines.
     * 
     * 3. TICKET VS ITINERARY:
     *    The 'Ticket' issued in TicketService is a legal document. Modification
     *    of PNR segments after issuance requires a Reissue or Exchange E-Ticket.
     */
    public function find() {
        // User must be authenticated to add a trip to their account
        $userId = $this->authenticate();
        $data = request_json();

        if (empty($data['reference']) || empty($data['last_name'])) {
            Response::json(['status' => false, 'message' => 'Missing reference or last name'], 400);
            return;
        }
        
        $reference = strtoupper(trim($data['reference']));
        $lastName = trim($data['last_name']);

        // 1. Find booking
        $booking = $this->bookingModel->getByReference($reference);
        if (!$booking) {
            Response::json(['status' => false, 'message' => 'Booking not found'], 404);
            return;
        }

        // 2. Verify Name Match (Case insensitive check if last name is part of passenger name)
        // Note: passenger_name in DB is "Title First Last" e.g., "Mr John Doe"
        if (stripos($booking['passenger_name'], $lastName) === false) {
             Response::json(['status' => false, 'message' => 'Booking found but name does not match.'], 403);
             return;
        }

        // 3. Link to User Account
        // Only link if not already linked OR if we allow re-linking (let's allow re-linking for now)
        $db = db();
        $stmt = $db->prepare("UPDATE bookings SET user_id = ? WHERE id = ?");
        $success = $stmt->execute([$userId, $booking['id']]);

        if ($success) {
            $booking['user_id'] = $userId; // Update local copy
             Response::json(['status' => true, 'message' => 'Trip found and added to your account', 'data' => $booking]);
        } else {
             Response::json(['status' => false, 'message' => 'Failed to link booking to account'], 500);
        }
    }
}
?>
